package com.atguigu.sparktuning.bean

case class School(id: Long, name: String, partition: Int)