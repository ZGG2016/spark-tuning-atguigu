package com.atguigu.sparktuning.bean

case class CourseShoppingCart( courseid: Long,
                               orderid: String,
                               coursename: String,
                               cart_discount: String,
                               sellmoney: String,
                               cart_createtime: String,
                               dt: String,
                               dn: String,
                               rand_courseid: String )