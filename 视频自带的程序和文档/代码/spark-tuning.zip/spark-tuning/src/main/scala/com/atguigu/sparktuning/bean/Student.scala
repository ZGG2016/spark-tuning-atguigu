package com.atguigu.sparktuning.bean

case class Student(id: Long, name: String, age: Int, partition: Int)