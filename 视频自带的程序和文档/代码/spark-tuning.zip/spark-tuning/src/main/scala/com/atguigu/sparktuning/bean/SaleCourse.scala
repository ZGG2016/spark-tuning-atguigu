package com.atguigu.sparktuning.bean

case class SaleCourse( courseid: Long,
                       coursename: String,
                       status: String,
                       pointlistid: Long,
                       majorid: Long,
                       chapterid: Long,
                       chaptername: String,
                       edusubjectid: Long,
                       edusubjectname: String,
                       teacherid: Long,
                       teachername: String,
                       coursemanager: String,
                       money: String,
                       dt: String,
                       dn: String,
                       rand_courseid: String )