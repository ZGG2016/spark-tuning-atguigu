package com.atguigu.sparktuning.bean

import java.sql.Timestamp

case class CoursePay( orderid: String,
                      discount: String,
                      paymoney: String,
                      createtime: String,
                      dt: String,
                      dn: String )
